Check-in Fox
============

Easy to use FourSquare client for Firefox OS
--------------------------------------------

As FourSquare expressed that they [don't have a plan yet for releasing their client for Firefox OS](https://twitter.com/4sqSupport/status/306790266734510080), I decided to implement some of the basic functionality so people can use the service until a full-fledged official client app is released.

The app focus is on quick and easy checking in to places, as effortlessly as it is humanly possible. :)
